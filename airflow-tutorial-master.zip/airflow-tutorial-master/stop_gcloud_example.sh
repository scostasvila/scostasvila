#!/bin/bash

docker-compose -f docker-compose-gcloud.yml down